package com.example.evitegiphydemo.rx.event;

import com.example.evitegiphydemo.ui.adapter.model.GiphyImageInfo;

public final class PreviewImageEvent {
  private final GiphyImageInfo imageInfo;

  public PreviewImageEvent(final GiphyImageInfo imageInfo) {
    this.imageInfo = imageInfo;
  }

  /**
   * Get the ImageInfo from the event.
   *
   * @return ImageInfo from the event.
   */
  public GiphyImageInfo getImageInfo() {
    return imageInfo;
  }
}
